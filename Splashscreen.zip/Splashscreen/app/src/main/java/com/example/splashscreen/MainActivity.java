package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.opengl.Visibility;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b1;
    EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button) findViewById(R.id.b1);
        et1 = (EditText) findViewById(R.id.et1);
    }

    public void b1Clicked(View v) {
        if (et1.getVisibility() == View.VISIBLE) {
            et1.setVisibility(View.GONE);
        } else {
            et1.setVisibility((View.VISIBLE));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("my_text", et1.getText().toString());
        outState.putInt("visibility", et1.getVisibility());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        et1.setText(savedInstanceState.getString("my_text"));
        et1.setText(savedInstanceState.getInt("visibility"));
    }
}
